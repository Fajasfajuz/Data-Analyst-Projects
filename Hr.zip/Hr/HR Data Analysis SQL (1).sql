#.... KPI_1 Average Attrition Rate For All Department

with table1 as(
select
hr_1.*
,Case when Attrition = "no" then 0 
else 1
end as Attrition_values
from Hr_1)
select
department
,avg(attrition_values) as 'average attrition'
from hr_2 as a
inner join table1 as b on a.Employee_ID =b.employeenumber
group by department;

#.... KPI_2 Average Hourly Rate of Male Resarch Scintist

select
JobRole
,Gender
,avg(HourlyRate) AS avg_Hourlyrate
from hr_1 
where gender="male" and JobRole="Research Scientist";

#......... KPI_3 Attrition rate vs momthly income sats
select
count(a.Attrition) as atri
,b.monthlyincome
from hr_1 as a inner join hr_2 as b on a.EmployeeNumber = b.Employee_ID
where a.Attrition = "yes" and MonthlyIncome <= 40000;

#.......KPI_4 Average working year for each departmenrt

select
a.department
,avg(b.TotalWorkingYears) as Avg_WorkingYear
from hr_1 as a inner join hr_2 as b on a.EmployeeNumber = b.Employee_ID
group by Department;

#.....KPI_5 Job Role vs Work life Balance

with table1 as (
select
JobRole
,avg(WorkLifeBalance) as worklifebalances
from hr_2 as a inner join hr_1 b on a.employee_id = b.EmployeeNumber
group by jobrole)
select
jobrole
,worklifebalances
,case when worklifebalances = 1 then "Poor"
 when worklifebalances = 2 then "Average"
  when worklifebalances = 3 then "Good"
  else "Excelent"
  end as Worklifebalance_Stats
from table1;

#.....KPI_6 Attrition rate vs year since Last promotion Relation

with table1 as (
select
YearsSinceLastPromotion
,count(case when Attrition ="yes" then 1 end) as Yes
,(case when Attrition ="no" then 0 end) as No
from 
hr_1 as a inner join hr_2 as b on a.employeenumber = b.employee_id
group by YearsSinceLastPromotion
order by YearsSinceLastPromotion asc)
select*
 ,round(yes/25105*100,2) as Percent_of_Yes,
 round(no/24895*100,2) as Percent_of_no
 from table1;
 


